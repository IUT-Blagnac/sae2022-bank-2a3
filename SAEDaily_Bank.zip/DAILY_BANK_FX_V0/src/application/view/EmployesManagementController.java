package application.view;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import application.DailyBankState;
import application.control.EmployesManagement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import model.data.Client;
import model.data.Employe;

public class EmployesManagementController implements Initializable {

	// Etat application
	private DailyBankState dbs;
	private EmployesManagement cm;

	// Fenêtre physique
	private Stage primaryStage;

	// Données de la fenêtre
	private ObservableList<Employe> olc;

	// Manipulation de la fenêtre
	public void initContext(Stage _primaryStage, EmployesManagement _cm, DailyBankState _dbstate) {
		this.cm = _cm;
		this.primaryStage = _primaryStage;
		this.dbs = _dbstate;
		this.configure();
	}

	private void configure() {
		this.primaryStage.setOnCloseRequest(e -> this.closeWindow(e));

		this.olc = FXCollections.observableArrayList();
		this.lvEmployes.setItems(this.olc);
		this.lvEmployes.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
		this.lvEmployes.getFocusModel().focus(-1);
		this.lvEmployes.getSelectionModel().selectedItemProperty().addListener(e -> this.validateComponentState());
		this.validateComponentState();
	}

	public void displayDialog() {
		this.primaryStage.showAndWait();
	}

	// Gestion du stage
	private Object closeWindow(WindowEvent e) {
		this.doCancel();
		e.consume();
		return null;
	}

	// Attributs de la scene + actions
	@FXML
	private TextField txtIdEmploye;
	@FXML
	private TextField txtIdAg;
	@FXML
	private ListView<Employe> lvEmployes;
	@FXML
	private Button btnDesactEmploye;
	@FXML
	private Button btnModifEmploye;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
	}

	@FXML
	private void doCancel() {
		this.primaryStage.close();
	}

	@FXML
	private void doRechercher() {
		int idEmp;
		try {
			String emp= this.txtIdEmploye.getText();
			if (emp.equals("")) {
				idEmp = -1;
			} else {
				idEmp = Integer.parseInt(emp);
				if (idEmp < 0) {
					this.txtIdEmploye.setText("");
					idEmp = -1;
				}
			}
		} catch (NumberFormatException nfe) {
			this.txtIdEmploye.setText("");
			idEmp = -1;
		}
		
		int idAg;
		try {
			String ag = this.txtIdAg.getText();
			if (ag.equals("")) {
				idAg = -1;
			} else {
				idAg = Integer.parseInt(ag);
				if (idAg < 0) {
					this.txtIdAg.setText("");
					idAg = -1;
				}
			}
		} catch (NumberFormatException nfe) {
			this.txtIdAg.setText("");
			idAg = -1;
		}
		if (idEmp != -1) {
			this.txtIdAg.setText("");
		} else {
			if (idAg != -1) {
				this.txtIdEmploye.setText("");
			}
		}	
				// Recherche des employes en BD. cf. AccessEmploye > getEmployes(.)
				// numCompte != -1 => recherche sur idAg
				// numCompte != -1 et debutId non vide => recherche nom/prenom
				// numCompte != -1 et debutNom vide => recherche tous les employes
				ArrayList<Employe> listeEmp;
				listeEmp = this.cm.getlisteComptesEmp(idEmp,idAg);

				this.olc.clear();
				for (Employe emp : listeEmp) {
					this.olc.add(emp);
				}

				this.validateComponentState();
			}


	@FXML
	private void doModifierEmploye() {

		int selectedIndice = this.lvEmployes.getSelectionModel().getSelectedIndex();
		if (selectedIndice >= 0) {
			Employe EmpMod = this.olc.get(selectedIndice);
			Employe result = this.cm.modifierEmploye(EmpMod);
			if (result != null) {
				this.olc.set(selectedIndice, result);
			}
		}
	}

	@FXML
	private void doDesactiverEmploye() {
	}

	@FXML
	private void doNouveauEmploye() {
		Employe employe;
		employe = this.cm.nouveauEmploye();
		if (employe != null) {
			this.olc.add(employe);
		}
	}

	private void validateComponentState() {
		// Non implémenté => désactivé
		this.btnDesactEmploye.setDisable(true);
		int selectedIndice = this.lvEmployes.getSelectionModel().getSelectedIndex();
		if (selectedIndice >= 0) {
			this.btnModifEmploye.setDisable(false);
		} else {
			this.btnModifEmploye.setDisable(true);
		}
	}
}
