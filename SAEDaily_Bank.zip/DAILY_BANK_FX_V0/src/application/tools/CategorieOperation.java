package application.tools;

public enum CategorieOperation {
	DEBIT, CREDIT
}