package application.view;

import java.io.IOException;
import java.util.ArrayList;

import application.control.SimulationAssuranceEditorPane;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import model.data.SimulationAssurance;

public class SimulationAssuranceEditorPaneController {
	// Fenêtre physique
			private Stage primaryStage;
			private SimulationAssuranceEditorPane sep;
			private ObservableList<SimulationAssurance> olAssurance;

			

			// Manipulation de la fenêtre
			public void initContext(Stage _primaryStage) {
				this.primaryStage = _primaryStage;
				this.configure();
			}

			private void configure() {
				this.primaryStage.setOnCloseRequest(e -> this.closeWindow(e));
				this.olAssurance = FXCollections.observableArrayList();
				this.lvAssurance.setItems(this.olAssurance);
				this.lvAssurance.selectionModelProperty();
				

			}

			public void displayDialog() {
				this.primaryStage.showAndWait();
			}

			// Gestion du stage
			private Object closeWindow(WindowEvent e) {
				this.doCancel();
				e.consume();
				return null;
			}
			
			@FXML
			private TextField txtCapitalEmprunté;
			@FXML
			private TextField txtDuréePret;
			@FXML
			private TextField txtTauxAssurance;
			@FXML
			private ListView<SimulationAssurance> lvAssurance;

			@FXML
			private void doCancel() {
				this.primaryStage.close();
			}

			@FXML
			private void doSimuler() throws IOException {
				double CapitalEmprunté = Double.parseDouble(this.txtCapitalEmprunté.getText().trim());
				double DuréePret = Double.parseDouble(this.txtDuréePret.getText().trim());
				double TauxAssurance = Double.parseDouble(this.txtTauxAssurance.getText().trim());
				
				ArrayList<SimulationAssurance> listeOP=new ArrayList<>() ;
				
				double Mensualite=((TauxAssurance/100)*CapitalEmprunté)/12;
				double Total=Mensualite*DuréePret;
				
				listeOP.add(new SimulationAssurance(Mensualite,DuréePret,Total));
				for (SimulationAssurance as : listeOP) {
					this.olAssurance.add(as);
				}

			}
			
			
}
