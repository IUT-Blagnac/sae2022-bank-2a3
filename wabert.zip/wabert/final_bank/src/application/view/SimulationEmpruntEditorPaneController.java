package application.view;

import java.io.IOException;
import java.util.ArrayList;

import application.control.SimulationEmpruntEditorPane;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import model.data.SimulationEmprunt;

public class SimulationEmpruntEditorPaneController {
	// Fenêtre physique
		private Stage primaryStage;
		private SimulationEmpruntEditorPane sep;
		private ObservableList<SimulationEmprunt> olEmprunt;

		

		// Manipulation de la fenêtre
		public void initContext(Stage _primaryStage) {
			this.primaryStage = _primaryStage;
			this.configure();
		}

		private void configure() {
			this.primaryStage.setOnCloseRequest(e -> this.closeWindow(e));
			this.olEmprunt = FXCollections.observableArrayList();
			this.lvEmprunt.setItems(this.olEmprunt);
			this.lvEmprunt.selectionModelProperty();

		}

		public void displayDialog() {
			this.primaryStage.showAndWait();
		}

		// Gestion du stage
		private Object closeWindow(WindowEvent e) {
			this.doCancel();
			e.consume();
			return null;
		}
		
	

		@FXML
		private void doCancel() {
			this.primaryStage.close();
		}
		
		@FXML
		private Label lblCapitalEmprunté;
		@FXML
		private Label lblDuréeEnAnnée;
		@FXML
		private Label lblTauxAnnuel;
		@FXML
		private Label lblType;
		@FXML
		private TextField txtCapitalEmprunté;
		@FXML
		private TextField txtDuréeEnAnnée;
		@FXML
		private TextField txtTauxAnnuel;
		@FXML
		private TextField txtType;
		@FXML
		private ListView<SimulationEmprunt> lvEmprunt;
		
		
		@FXML
		private void doSimuler() throws IOException {
			this.olEmprunt.clear();
			
			double CapitalEmprunté = Double.parseDouble(this.txtCapitalEmprunté.getText().trim());
			double DuréeEnAnnée = Double.parseDouble(this.txtDuréeEnAnnée.getText().trim());
			double TauxAnnuel = Double.parseDouble(this.txtTauxAnnuel.getText().trim());
			String Type = this.txtType.getText().trim();
			double TauxApplicable ;
			double NombreDePériode;
			if(Type.equals("mois")) {
				TauxApplicable =(TauxAnnuel/100)/12 ;
				NombreDePériode =DuréeEnAnnée*12;
			}else {
				TauxApplicable =(TauxAnnuel/100);
				NombreDePériode =DuréeEnAnnée;
			}
			
			
			ArrayList<SimulationEmprunt> listeOP=new ArrayList<>() ;
			double NumPériode;
			double CapitalRestantDebut;
			double MontantInteret;
			double MontantPrincipal; //mois/an
			double MontantRembourser;
			double CapitalRestantFin;
			CapitalRestantDebut=CapitalEmprunté;
			MontantRembourser=CapitalRestantDebut*(TauxApplicable/(1-Math.pow((1+TauxApplicable),-NombreDePériode)));
			for(int i=1;i<NombreDePériode+1;i++) {
				NumPériode=i;
				MontantInteret=CapitalRestantDebut*TauxApplicable;
				MontantPrincipal=MontantRembourser-MontantInteret;
				CapitalRestantFin=CapitalRestantDebut-MontantPrincipal;
				listeOP.add(new SimulationEmprunt(NumPériode,CapitalRestantDebut,MontantInteret,MontantPrincipal,MontantRembourser,CapitalRestantFin));
				CapitalRestantDebut=CapitalRestantFin;
			}
			for (SimulationEmprunt es : listeOP) {
				this.olEmprunt.add(es);
			}
		}
		
		
}
