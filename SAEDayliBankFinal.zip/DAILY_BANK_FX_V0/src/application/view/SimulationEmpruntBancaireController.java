package application.view;



import application.control.SimulationAssuranceEditorPane;
import application.control.SimulationBancaireManagement;
import application.control.SimulationEmpruntEditorPane;
import javafx.fxml.FXML;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;


public class SimulationEmpruntBancaireController {
	 private SimulationBancaireManagement sbm;
	
	

	// Fenêtre physique
	private Stage primaryStage;

	

	// Manipulation de la fenêtre
	public void initContext(Stage _primaryStage) {
		this.primaryStage = _primaryStage;
		this.configure();
	}

	private void configure() {
		this.primaryStage.setOnCloseRequest(e -> this.closeWindow(e));

	}

	public void displayDialog() {
		this.primaryStage.showAndWait();
	}

	// Gestion du stage
	private Object closeWindow(WindowEvent e) {
		this.doCancel();
		e.consume();
		return null;
	}
	
	

	
	@FXML
	private void doSimulationBancaire() {
		SimulationEmpruntEditorPane cm = new SimulationEmpruntEditorPane(this.primaryStage);
		cm.doSimulationEmpruntDialog();
	}
	

	
	@FXML
	private void doSimulationAssurance() {
		SimulationAssuranceEditorPane cm = new SimulationAssuranceEditorPane(this.primaryStage);
		cm.doSimulationAssuranceDialog();
	}

	
	@FXML
	private void doCancel() {
		this.primaryStage.close();
	}
	
}
