package application.control;

import java.util.ArrayList;

import application.DailyBankApp;
import application.DailyBankState;
import application.tools.EditionMode;
import application.tools.StageManagement;
import application.view.EmployesManagementController;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.data.Employe;
import model.orm.AccessEmploye;
import model.orm.exception.ApplicationException;
import model.orm.exception.DatabaseConnexionException;

public class EmployesManagement {

	private Stage primaryStage;
	private DailyBankState dbs;
	private EmployesManagementController cmc;
	
	/**
	 * Permet de generer la fenetre management de l'employe
	 * @param _parentStage de type Stage
	 * @param _dbstate de type DailyBankState
	 */
	public EmployesManagement(Stage _parentStage, DailyBankState _dbstate) {
		this.dbs = _dbstate;
		try {
			FXMLLoader loader = new FXMLLoader(EmployesManagementController.class.getResource("employesmanagement.fxml"));//Permet de recuperer et de charger la vue fxml
			BorderPane root = loader.load();

			Scene scene = new Scene(root, root.getPrefWidth()+50, root.getPrefHeight()+10);
			scene.getStylesheets().add(DailyBankApp.class.getResource("application.css").toExternalForm());//Permet de recuperer et d'appliquer le style a la vue

			this.primaryStage = new Stage();
			this.primaryStage.initModality(Modality.WINDOW_MODAL);
			this.primaryStage.initOwner(_parentStage);
			StageManagement.manageCenteringStage(_parentStage, this.primaryStage);
			this.primaryStage.setScene(scene);
			this.primaryStage.setTitle("Gestion des employes");//on definit le titre de la fenetre
			this.primaryStage.setResizable(false);
                        
                        this.cmc = loader.getController();
			this.cmc.initContext(this.primaryStage, this, _dbstate);

		} catch (IOException e) {
                    System.out.println("MOUAHAHAHAHA");
		}
	}

	public void doEmployeManagementDialog() {
		this.cmc.displayDialog();
	}
	
	/**
	 *Permet de generer et modifier l'Employe 
	 * @param c de type Employe
	 * @return l'employe result
	 */
	public Employe modifierEmploye(Employe c) {
		EmployesEditorPane cep = new EmployesEditorPane(this.primaryStage, this.dbs);
		Employe result = cep.doEmployeEditorDialog(c, EditionMode.MODIFICATION);
		if (result != null) {
			try {
				AccessEmploye ac = new AccessEmploye();
				ac.updateEmploye(result);
			} catch (DatabaseConnexionException e) {
				ExceptionDialog ed = new ExceptionDialog(this.primaryStage, this.dbs, e);
				ed.doExceptionDialog();
				result = null;
				this.primaryStage.close();
			} catch (ApplicationException ae) {
				ExceptionDialog ed = new ExceptionDialog(this.primaryStage, this.dbs, ae);
				ed.doExceptionDialog();
				result = null;
			}
		}
		return result;
	}
	
	/**
	 * Permet de generer et ajouter un nouveau client
	 * @return client le nouveau client
	 */
	public Employe nouveauEmploye() {
		Employe employe;
		EmployesEditorPane cep = new EmployesEditorPane(this.primaryStage, this.dbs);
		employe = cep.doEmployeEditorDialog(null, EditionMode.CREATION);
		if (employe != null) {
			try {
				AccessEmploye ac = new AccessEmploye();

				ac.insertEmploye(employe);
			} catch (DatabaseConnexionException e) {
				ExceptionDialog ed = new ExceptionDialog(this.primaryStage, this.dbs, e);
				ed.doExceptionDialog();
				this.primaryStage.close();
				employe = null;
			} catch (ApplicationException ae) {
				ExceptionDialog ed = new ExceptionDialog(this.primaryStage, this.dbs, ae);
				ed.doExceptionDialog();
				employe = null;
			}
		}
		return employe;
	}
	
	
	/**
	 * Permet de generer et modifier le compte du client
	 * @param c le compte du client a generer
	 */
	//public void gererComptesClient(Employe c) {
	//	ComptesManagement cm = new ComptesManagement(this.primaryStage, this.dbs, c);
	//	cm.doComptesManagementDialog();
	//}
	
	/**
	 * Permet de generer et chercher le compte d'un employe et de l'ajouter a une liste
	 * @param _debutIdEmp
	 * @param idAg
	 * @return listeCli la liste de Client
	 */
	public ArrayList<Employe> getlisteComptesEmp(int _debutIdEmp, int idAg) {
		ArrayList<Employe> listeEmp = new ArrayList<>();
		try {
			// Recherche des clients en BD. cf. AccessClient > getClients(.)
			// numCompte != -1 => recherche sur numCompte
			// numCompte != -1 et debutNom non vide => recherche nom/prenom
			// numCompte != -1 et debutNom vide => recherche tous les clients

			AccessEmploye ac = new AccessEmploye();
			listeEmp = ac.getEmployeLIST(_debutIdEmp, idAg); 

		} catch (DatabaseConnexionException e) {
			ExceptionDialog ed = new ExceptionDialog(this.primaryStage, this.dbs, e);
			ed.doExceptionDialog();
			this.primaryStage.close();
			listeEmp = new ArrayList<>();
		} catch (ApplicationException ae) {
			ExceptionDialog ed = new ExceptionDialog(this.primaryStage, this.dbs, ae);
			ed.doExceptionDialog();
			listeEmp = new ArrayList<>();
		}
		return listeEmp;
	}
}
