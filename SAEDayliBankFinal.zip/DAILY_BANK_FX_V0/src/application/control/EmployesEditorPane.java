package application.control;

import application.DailyBankApp;
import application.DailyBankState;
import application.tools.EditionMode;
import application.tools.StageManagement;
import application.view.EmployesEditorPaneController;
import application.view.ClientsManagementController;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import model.data.Employe;

public class EmployesEditorPane {

	private Stage primaryStage;
	private EmployesEditorPaneController cepc;
	
	
	
	/**
	 * Permet de generer la fenetre editeur de l'employe
	 * @param _parentStage de type Stage
	 * @param _dbstate de type DailyBankState
	 */
	public EmployesEditorPane(Stage _parentStage, DailyBankState _dbstate) {

		try {
			FXMLLoader loader = new FXMLLoader(ClientsManagementController.class.getResource("employeeditorpane.fxml"));//Permet de recuperer et de charger la vue fxml
			BorderPane root = loader.load();

			Scene scene = new Scene(root, root.getPrefWidth()+20, root.getPrefHeight()+10);
			scene.getStylesheets().add(DailyBankApp.class.getResource("application.css").toExternalForm());//Permet de recuperer et d'appliquer le style a la vue

			this.primaryStage = new Stage();
			this.primaryStage.initModality(Modality.WINDOW_MODAL);
			this.primaryStage.initOwner(_parentStage);
			StageManagement.manageCenteringStage(_parentStage, this.primaryStage);
			this.primaryStage.setScene(scene);
			this.primaryStage.setTitle("Gestion d'un client");//on definit le titre de la fenetre
			this.primaryStage.setResizable(false);

			this.cepc = loader.getController();
			this.cepc.initContext(this.primaryStage, _dbstate);

		} catch (IOException e) {
                    System.out.println("Pb avec EmployeEditorPane.java");
		}
	}

	public Employe doEmployeEditorDialog(Employe employe, EditionMode em) {
		return this.cepc.displayDialog(employe, em);
	}
}
