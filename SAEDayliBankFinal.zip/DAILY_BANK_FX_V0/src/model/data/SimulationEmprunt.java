package model.data;

public class SimulationEmprunt {
	public double NumPériode;
	public double CapitalRestantDebut;
	public double MontantInteret;
	public double MontantPrincipal; //mois/an
	public double MontantRembourser;
	public double CapitalRestantFin;

	public SimulationEmprunt(double NumPériode, double CapitalRestantDebut, double MontantInteret, double MontantPrincipal, double MontantRembourser,double CapitalRestantFin) {
		this.NumPériode = NumPériode;
		this.CapitalRestantDebut = CapitalRestantDebut;
		this.MontantInteret = MontantInteret;
		this.MontantPrincipal = MontantPrincipal;
		this.MontantRembourser = MontantRembourser;
		this.CapitalRestantFin = CapitalRestantFin;
	}

	public SimulationEmprunt() {
		this.NumPériode = 0;
		this.CapitalRestantDebut = 0;
		this.MontantInteret = 0;
		this.MontantPrincipal = 0;
		this.MontantRembourser = 0;
		this.CapitalRestantFin = 0;
	}
	
	@Override
	public String toString() {
		String s = "" + String.format("%.0f", this.NumPériode) + " : CapitalRestantDebut=" + String.format("%.2f", this.CapitalRestantDebut)
				+ "  ,  MontantInteret=" + String.format("%.2f", this.MontantInteret)
				+ "  ,  MontantPrincipal=" + String.format("%.2f", this.MontantPrincipal)
				+ "  ,  MontantRembourser=" + String.format("%.2f", this.MontantRembourser)
				+ "  ,  CapitalRestantFin=" + String.format("%.2f", this.CapitalRestantFin);
		return s;
	}

}
