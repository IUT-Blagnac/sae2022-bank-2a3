package model.data;

public class SimulationAssurance {
	double Mensualite;
	double DuréePret;
	double Total;
	
	public SimulationAssurance(double Mensualite, double DuréePret, double Total) {
		this.Mensualite = Mensualite;
		this.DuréePret = DuréePret;
		this.Total = Total;

	}

	public SimulationAssurance() {
		this.Mensualite = 0;
		this.DuréePret = 0;
		this.Total = 0;

	}
	
	@Override
	public String toString() {
		String s = " Mensualite=" + String.format("%.0f", this.Mensualite) + " : CapitalRestantDebut=" + String.format("%.2f", this.DuréePret)
				+ "  ,  Total=" + String.format("%.2f", this.Total);
		return s;
	}

}
