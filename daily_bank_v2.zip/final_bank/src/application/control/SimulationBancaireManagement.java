package application.control;

import application.DailyBankApp;
import application.tools.StageManagement;
import application.view.SimulationEmpruntBancaireController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class SimulationBancaireManagement {
	private Stage primaryStage;
	private SimulationEmpruntBancaireController seb;
	
	/**
	 * Permet de generer la fenetre management de la simulation bancaire
	 * @param _parentStage de type Stage
	 * @param _dbstate de type DailyBankState
	 */
	public SimulationBancaireManagement(Stage _parentStage) {
		try {
			FXMLLoader loader = new FXMLLoader(SimulationEmpruntBancaireController.class.getResource("simulationbancairemanagement.fxml"));//Permet de recuperer et de charger la vue fxml
			BorderPane root = loader.load();

			Scene scene = new Scene(root, root.getPrefWidth()+50, root.getPrefHeight()+10);
			scene.getStylesheets().add(DailyBankApp.class.getResource("application.css").toExternalForm());//Permet de recuperer et d'appliquer le style a la vue

			this.primaryStage = new Stage();
			this.primaryStage.initModality(Modality.WINDOW_MODAL);
			this.primaryStage.initOwner(_parentStage);
			StageManagement.manageCenteringStage(_parentStage, this.primaryStage);
			this.primaryStage.setScene(scene);
			this.primaryStage.setTitle("Gestion Simulation Bancaire");//on definit le titre de la fenetre
			this.primaryStage.setResizable(false);

			this.seb = loader.getController();
			this.seb.initContext(this.primaryStage);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void doSimulationBancaireManagementDialog() {
		this.seb.displayDialog();
	}
	
	
	
	

}
